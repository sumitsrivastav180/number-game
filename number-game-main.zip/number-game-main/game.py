#python 2.7.15

print ("PICK A NUMBER! ")
print ("MULTIPLY WITH 2!")
print ("ADD 10!")
print ("DIVIDE BY 2!")
num = int(input("Enter Your Result :"))
print "The number is :", num - 5
print ("If you want to play again, rerun the code")
